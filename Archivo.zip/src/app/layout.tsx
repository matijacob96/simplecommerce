import { Inter } from "next/font/google"
import Provider from "./provider"
import { Header } from "./components/Header"
import { Box } from '@chakra-ui/react';

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
})

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html className={inter.className} suppressHydrationWarning>
      <head />
      <body>
        <Provider>
          <Header />
          <Box pt="60px">
            {children}
          </Box>
        </Provider>
      </body>
    </html>
  )
}