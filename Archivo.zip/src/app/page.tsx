"use client";

import { useState, useEffect } from "react";
import { Box, createListCollection, Input, SelectContent, SelectItem, SelectLabel, SelectRoot, SelectTrigger, SelectValueText } from "@chakra-ui/react";

export default function Catalog() {
  const [products, setProducts] = useState<Array<{ name: string; price: number }>>([]);

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<string[]>(["all"]);

  useEffect(() => {
    const fetchProducts = async () => {
      const response = await fetch(
        `/api/products?${search && 'search=' + encodeURIComponent(search) + '&'}filter=${encodeURIComponent(filter.join(','))}`
      );
      const data = await response.json();
      setProducts(data);
    };
    fetchProducts();
  }, [search, filter]);

  const values = createListCollection({
    items: [
      { label: "Todos", value: "all" },
      { label: "Categoría 1", value: "cat1" },
      { label: "Categoría 2", value: "cat2" },
      { label: "Categoría 3", value: "cat3" },
    ],
  });

  return (
    <Box p={4}>
      <Input
        placeholder="Buscar producto..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        mb={4}
      />
      <SelectRoot collection={values} onValueChange={(e) => setFilter(e.value)}>
        <SelectLabel>Categoría</SelectLabel>
        <SelectTrigger>
          <SelectValueText placeholder="Select movie" />
        </SelectTrigger>
        <SelectContent>
          {values.items.map((cat) => (
            <SelectItem item={cat} key={cat.value}>
              {cat.label}
            </SelectItem>
          ))}
        </SelectContent>
      </SelectRoot>

      {products.map((product) => (
        <Box key={product.name} p={2} borderWidth={1} mb={2}>
          {product.name} - ${product.price}
        </Box>
      ))}
    </Box>
  );
}