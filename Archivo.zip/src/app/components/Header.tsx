import { Flex, Heading, Link } from "@chakra-ui/react";

export function Header() {
    return (
        <Flex
            position="fixed"
            top={0}
            left={0}
            right={0}
            height="60px"
            px={4}
            bg="black"
            zIndex={1000}
            alignItems="center"
        >
            <Heading as="h1" size="md" whiteSpace="nowrap" overflow="hidden" textOverflow="ellipsis" >
                <Link href="/" ml="auto">
                    SimpleCommerce
                </Link>
            </Heading>
            <Link href="/pedidos" ml="auto">
                Pedidos
            </Link>
        </Flex>
    );
}