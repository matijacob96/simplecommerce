import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function GET(request: NextRequest) {
  const search = request.nextUrl.searchParams.get("search") || "";
  const filter = request.nextUrl.searchParams.get("filter") || "all";

  let where: any = {};
  if (search) {
    where.name = {
      contains: search,
      mode: "insensitive",
    };
  }
  if (filter !== "all") {
    where.category = filter;
  }

  const data = await prisma.product.findMany({
    where,
    select: { name: true, price: true },
  });

  const formattedProducts = data.map((p) => ({
    name: p.name,
    price: p.price.toNumber(),
  }));

  return NextResponse.json(formattedProducts);
}