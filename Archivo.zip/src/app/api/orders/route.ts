import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { products, shippingCost } = body;

  if (!products || !Array.isArray(products) || products.length === 0) {
    return NextResponse.json({ error: "Debe haber al menos un producto." }, { status: 400 });
  }

  try {
    const totalProductCost = products.reduce((acc, product) => acc + (product.quantity * product.cost), 0);
    if (totalProductCost === 0) {
      return NextResponse.json({ error: "El costo total de los productos no puede ser cero." }, { status: 400 });
    }

    for (const product of products) {
      if (!product.name || isNaN(parseInt(product.quantity)) || isNaN(parseFloat(product.cost))) {
        return NextResponse.json({ error: "Datos de producto inválidos." }, { status: 400 });
      }

      const productTotalCost = product.quantity * product.cost;
      const proratedShippingCost = (productTotalCost / totalProductCost) * shippingCost;

      let existingProduct = await prisma.product.findFirst({
        where: { name: product.name },
        select: { id: true, stock: true },
      });

      let productId;
      if (!existingProduct) {
        const newProduct = await prisma.product.create({
          data: { name: product.name, stock: 0, price: 0, image: product.imageUrl || null },
          select: { id: true, stock: true },
        });
        productId = newProduct.id;
      } else {
        productId = existingProduct.id;
      }

      await prisma.order.create({
        data: {
          product_name: product.name,
          quantity: parseInt(product.quantity),
          supplier: product.supplier || null,
          shipping_cost: proratedShippingCost,
        },
      });

      const newStock = (existingProduct ? existingProduct.stock : 0) + parseInt(product.quantity);
      await prisma.product.update({
        where: { id: productId },
        data: { stock: newStock, price: product.cost },
      });
    }

    return NextResponse.json({ message: "Pedidos cargados exitosamente!" });
  } catch (error) {
    console.error("Error al procesar los pedidos:", error);
    return NextResponse.json({ error: "Fallo al procesar los pedidos." }, { status: 500 });
  }
}