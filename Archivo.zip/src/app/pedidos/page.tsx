"use client";

import { useState, useEffect } from "react";
import {
  Box,
  Button,
  Input,
  Table,
  Text
} from "@chakra-ui/react";
import { FormControl, FormLabel } from "@chakra-ui/form-control";

export default function PedidosPage() {
  const [products, setProducts] = useState([
    { quantity: 0, name: "", cost: 0, supplier: "", imageUrl: "" },
  ]);
  const [shippingCost, setShippingCost] = useState(0);
  const [proratedCosts, setProratedCosts] = useState<any[]>([]);

  const addProduct = () => {
    setProducts([...products, { quantity: 0, name: "", cost: 0, supplier: "", imageUrl: "" }]);
  };

  const removeProduct = (index: number) => {
    const newProducts = [...products];
    newProducts.splice(index, 1);
    setProducts(newProducts);
  };

  const handleChange = (e: any, index: any, field: any) => {
    const newProducts: any = [...products];
    if (field === "quantity" || field === "cost") {
      newProducts[index][field] = parseFloat(e.target.value) || 0;
    } else {
      newProducts[index][field] = e.target.value;
    }
    setProducts(newProducts);
  };

  const handleShippingCostChange = (e: any) => {
    setShippingCost(parseFloat(e.target.value) || 0);
  };

  const calculateProratedCosts = () => {
    const totalProductCost = products.reduce((acc, product) => acc + (product.quantity * product.cost), 0);
    if (totalProductCost === 0) {
      setProratedCosts(products.map(() => ({ proratedShippingCost: 0, totalCost: 0 })));
      return;
    }
    const prorated = products.map((product) => {
      const productTotalCost = product.quantity * product.cost;
      const proratedShipping = (productTotalCost / totalProductCost) * shippingCost;
      const totalCost = productTotalCost + proratedShipping;
      return { proratedShippingCost: proratedShipping, totalCost };
    });
    setProratedCosts(prorated);
  };

  useEffect(() => {
    calculateProratedCosts();
  }, [products, shippingCost]);

  return (
    <Box p={4}>
      <Table.Root variant="outline">
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeader>Cantidad</Table.ColumnHeader>
            <Table.ColumnHeader>Nombre Producto</Table.ColumnHeader>
            <Table.ColumnHeader>Costo</Table.ColumnHeader>
            <Table.ColumnHeader>Proveedor</Table.ColumnHeader>
            <Table.ColumnHeader>Url Imagen</Table.ColumnHeader>
            <Table.ColumnHeader>Costo de envío prorrateado</Table.ColumnHeader>
            <Table.ColumnHeader>Total</Table.ColumnHeader>
            <Table.ColumnHeader></Table.ColumnHeader>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {products.map((product, index) => (
            <Table.Row key={index}>
              <Table.Cell>
                <Input
                  type="number"
                  value={product.quantity}
                  onChange={(e) => handleChange(e, index, "quantity")}
                  placeholder="Cantidad"
                />
              </Table.Cell>
              <Table.Cell>
                <Input
                  value={product.name}
                  onChange={(e) => handleChange(e, index, "name")}
                  placeholder="Nombre del producto"
                />
              </Table.Cell>
              <Table.Cell>
                <Input
                  type="number"
                  step="0.01"
                  value={product.cost}
                  onChange={(e) => handleChange(e, index, "cost")}
                  placeholder="Costo"
                />
              </Table.Cell>
              <Table.Cell>
                <Input
                  value={product.supplier}
                  onChange={(e) => handleChange(e, index, "supplier")}
                  placeholder="Proveedor (opcional)"
                />
              </Table.Cell>
              <Table.Cell>
                <Input
                  value={product.imageUrl}
                  onChange={(e) => handleChange(e, index, "imageUrl")}
                  placeholder="URL de imagen (opcional)"
                />
              </Table.Cell>
              <Table.Cell>
                <Text>{proratedCosts[index]?.proratedShippingCost?.toFixed(2) || "0.00"}</Text>
              </Table.Cell>
              <Table.Cell>
                <Text>{proratedCosts[index]?.totalCost?.toFixed(2) || "0.00"}</Text>
              </Table.Cell>
              <Table.Cell>
                <Button colorScheme="red" size="sm" onClick={() => removeProduct(index)}>
                  Eliminar
                </Button>
              </Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table.Root>
      <Box mt={4}>
        <FormControl mb={4}>
          <FormLabel>Costo de envío</FormLabel>
          <Input
            type="number"
            step="0.01"
            placeholder="Costo de envío"
            value={shippingCost}
            onChange={handleShippingCostChange}
          />
        </FormControl>
      </Box>
      <Box mt={4}>
        <Button colorScheme="blue" onClick={addProduct}>Agregar producto</Button>
      </Box>
      <Box mt={4}>
        <Button colorScheme="green" onClick={async () => {
          try {
            const response = await fetch("/api/orders", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ products, shippingCost }),
            });
            if (!response.ok) {
              const error = await response.json();
              alert("Error: " + error.error);
              return;
            }
            const message = await response.json();
            alert(message.message);
            setProducts([{ quantity: 0, name: "", cost: 0, supplier: "", imageUrl: "" }]);
            setShippingCost(0);
          } catch (error: any) {
            alert("Error al enviar los datos: " + error.message);
          }
        }}>Enviar Pedidos</Button>
      </Box>
    </Box>
  );
}