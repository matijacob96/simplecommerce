-- AlterTable
ALTER TABLE "Order" ALTER COLUMN "supplier" DROP NOT NULL;
