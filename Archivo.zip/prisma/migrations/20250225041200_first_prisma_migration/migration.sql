-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "shipping_cost" DECIMAL(65,30) NOT NULL DEFAULT 0.0;
